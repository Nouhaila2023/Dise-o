
# Diseño de Interfaces
## Capítulo 2
CSS y Flexbox
Ejemplos de maquetación utilizando el sistema de grids estándar
